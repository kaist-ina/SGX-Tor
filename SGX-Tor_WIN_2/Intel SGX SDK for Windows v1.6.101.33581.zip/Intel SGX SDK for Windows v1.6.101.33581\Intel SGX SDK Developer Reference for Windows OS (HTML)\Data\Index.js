CMCXmlParser._FilePathToXmlStringMap.Add(
	'Index',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultTargetIndex Count=\"0\">' +
	'    <IndexEntry>' +
	'        <Entries />' +
	'        <Links />' +
	'        <SeeAlsoLinks />' +
	'        <IndexControlLinks />' +
	'        <SortAsLinks />' +
	'    </IndexEntry>' +
	'</CatapultTargetIndex>'
);
