CMCXmlParser._FilePathToXmlStringMap.Add(
	'Filters',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<CatapultSearchFilterSet>' +
	'    <SearchFilter Name=\"My Subset\">' +
	'    </SearchFilter>' +
	'</CatapultSearchFilterSet>'
);
