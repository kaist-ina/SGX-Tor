CMCXmlParser._FilePathToXmlStringMap.Add(
	'Synonyms',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<MadCapSynonyms>' +
	'    <Groups />' +
	'    <Directional />' +
	'</MadCapSynonyms>'
);
