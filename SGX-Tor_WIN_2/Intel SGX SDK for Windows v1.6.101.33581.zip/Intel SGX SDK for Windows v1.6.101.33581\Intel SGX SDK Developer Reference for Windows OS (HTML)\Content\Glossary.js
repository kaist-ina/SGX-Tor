CMCXmlParser._FilePathToXmlStringMap.Add(
	'Glossary',
	'<?xml version=\"1.0\" encoding=\"utf-8\"?>' +
	'<html xmlns:MadCap=\"http://www.madcapsoftware.com/Schemas/MadCap.xsd\" MadCap:tocPath=\"\" MadCap:InPreviewMode=\"false\" MadCap:PreloadImages=\"false\" MadCap:RuntimeFileType=\"Glossary\" MadCap:TargetType=\"WebHelp\" lang=\"en-us\" xml:lang=\"en-us\" MadCap:PathToHelpSystem=\"../\" MadCap:HelpSystemFileName=\"Default.xml\">' +
	'    <head>' +
	'        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />' +
	'        <link href=\"SkinSupport/MadCap.css\" rel=\"stylesheet\" type=\"text/css\" />' +
	'        <title>Glossary</title>' +
	'        <link href=\"Resources/Stylesheets/intel_css_styles.css\" rel=\"stylesheet\" type=\"text/css\" />' +
	'        <script src=\"SkinSupport/MadCapAll.js\" type=\"text/javascript\">' +
	'        </script>' +
	'    </head>' +
	'    <body style=\"background-color: #fafafa;\">' +
	'        <div id=\"GlossaryBody\">' +
	'            <div class=\"GlossaryPageEntry\">' +
	'                <div class=\"GlossaryPageTerm\">' +
	'                    <a href=\"javascript:void(0);\" class=\"GlossaryPageTerm\" id=\"MCDropDownHotSpot_2960394885_0\" onclick=\"FMCDropDown( this ); FMCScrollToVisible( window, this.parentNode.parentNode ); return false;\">My Term</a>' +
	'                    <a name=\"2960394885_anchor1\">' +
	'                    </a>' +
	'                </div>' +
	'                <div class=\"GlossaryPageDefinition\" id=\"MCDropDownBody_2960394885_0\" style=\"display: none;\">My definition</div>' +
	'            </div>' +
	'        </div>' +
	'        <p>&#160;</p>' +
	'        <script type=\"text/javascript\" src=\"SkinSupport/MadCapBodyEnd.js\">' +
	'        </script>' +
	'    </body>' +
	'</html>'
);
